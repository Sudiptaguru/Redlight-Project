<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
        
	public function __construct() {
		parent::__construct();
		$this->CI = & get_instance();
		$this->load->model('mcommon');
	}

	protected function is_logged_in() {
		return $this->session->userdata('users') ? 1 : 0;
	}

    protected function is_logged_in_admin() {
        return $this->session->userdata('admin') ? 1 : 0;
    }

    protected function _loadView($data)
    {
       $this->load->view('admin/layouts/index', $data);
    }
	
    public function isJSON($string)
    {
        $valid = is_string($string) && is_array(json_decode($string, true)) ? true : false;
        if (!$valid) {
            $this->response_to_json(FALSE, "Not JSON", 401);
        }
    }

    /*
     Process json from request
     */
    function extract_json($key)
    {
        return json_decode($key, TRUE);
    }

    /*
        Methods to check all necessary fields inside a requested post body
    */
    public function validateArray($keys, $arr)
    {
        return !array_diff_key(array_flip($keys), $arr);
    }
    /*
     Set response message
     response_to_json = set_response
     */
    //public function response_to_json($success = TRUE, $message = "success", $data = NULL, $extraField = NULL, $extraData = NULL)
    public function response_to_json($success = TRUE, $message = "success", $data = NULL, $extraField = NULL, $extraData = NULL)
    {
        $response = ["success" => $success, "message" => $message, "data" => $data];
        if ($extraField != NULL && $extraData != NULL) {
            $response[$extraField] = $extraData;
        }
        print json_encode($response);
        die;
    }

    protected function commonFileArrayUpload($path = '', $images = array(),$fileTypes = '')
    {     
        $file_names= array();
        $upPath = FCPATH . $path;
        if (!file_exists($upPath)) {
            mkdir($upPath, 0777, true);
        }
        if ($fileTypes == '') {
            $fileTypes = 'gif|jpg|png|jpeg|JPEG|JPG|GIF|PNG';
        }
        $config = array(
            'upload_path' => $upPath,
            'allowed_types' =>  $fileTypes,
            'overwrite' => TRUE,
            'max_size' => "8192000",
            /*'max_height' => "1536",
            'max_width' => "2048",*/
            'encrypt_name' => TRUE
        );
        $this->load->library('upload', $config);
        for ($p = 0; $p < count($images['name']); $p++) {
            if ($images['name'][$p] != '') {
                $_FILES['file']['name']     = $images['name'][$p];
                $_FILES['file']['type']     = $images['type'][$p];
                $_FILES['file']['tmp_name'] = $images['tmp_name'][$p];
                $_FILES['file']['error']    = $images['error'][$p];
                $_FILES['file']['size']     = $images['size'][$p];
                $config['file_name']        = time() . $images['name'][$p];
                $this->upload->initialize($config);
                if ($this->upload->do_upload('file')) {
                    $imageDetailArray = $this->upload->data();
                   $file_names[] =$imageDetailArray['file_name'] ;
                    // $this->cm->insert($db, array($dbColmn => $dbVal, "image" => $imageDetailArray['file_name']));
                }else{
                     print_r( $this->upload->display_errors());
                }
            }
        }
        return $file_names;
    }

    protected function commonFileUpload($path = '', $imageName = '', $imageInputName = '', $fileTypes = '', $oldImage = '')
    {
        if ($fileTypes == '') {
            $fileTypes = 'gif|jpg|png|jpeg|JPEG|JPG|GIF|PNG';
        }
     
        $pro_image = '';
        $upPath = FCPATH . $path;
        if (!file_exists($upPath)) {
            mkdir($upPath, 0777, true);
        }
        $config = array(
            'upload_path' => $upPath,
            'allowed_types' => $fileTypes,
            'overwrite' => true,
            'max_size' => "8192000",
            /*'max_height' => "1536",
            'max_width' => "2048",*/
            'encrypt_name' => true,
        );
        $config['file_name'] = time() . $imageName;
         $this->load->library('upload', $config);
        $this->upload->initialize($config);
       
        if ($this->upload->do_upload($imageInputName)) {
            $imageDetailArray = $this->upload->data();
            $pro_image = $imageDetailArray['file_name'];
            $status = 1 ; 
            $data = array('status'=>$status ,'image'=>$pro_image  );
            if ($oldImage != '') {
                if (file_exists($upPath . $oldImage)) {
                    unlink($upPath . $oldImage);
                }
            }
        } else {
            $pro_image = $this->upload->display_errors();
            $data = array('status'=>0 ,'image'=>$pro_image  );
        }
         // print_r( $this->upload->display_errors());
        // print_r($pro_image);
        return $data;
    }

    // function email_settings(){
    //     $config=array();
    //     $config['protocol']     = 'smtp';
    //     $config['smtp_host']    = 'mail.met-technologies.com';
    //     $config['smtp_port']    = '465';        
    //     $config['smtp_user']    =  'devfitser@met-technologies.com';
    //     $config['smtp_pass']    = 'SARYD^z(B${F';
    //     $config['charset']      = 'utf-8';
    //     $config['newline']      = "\r\n";
    //     $config['mailtype']     = 'html'; // or html
    //     $config['validation']   = TRUE; // bool whether to validate email or not     
    //     return $config; 
    // } 

    function registration_mail($params){
        // print_r($params);
        $params['config']=email_settings();
        $obj =get_object();
        $obj->load->library('email');
        $obj->email->initialize($params['config']);
        $obj->email->from('info@met-technologies.com',$params['from']); 
        $obj->email->to($params['to']); 
        $obj->email->subject($params['subject']);
        $obj->email->message($params['message']);
        
        // if($params['filepath']!=''){
        //   $obj->email->attach($params['filepath']);  
        // }
 
        if (!$this->email->send())
        {    
        // echo $this->email->print_debugger();
        // die;
        } 

       return 1;
    } 

    // function sendmail($params){     
    //     echo "hello";
    //     print_r($params);
    //     $obj =get_object();
    //     $obj->load->library('email');
    //     $obj->email->initialize($params['config']);
    //     $obj->email->from('info@met-technologies.com',$params['from']); 
    //     $obj->email->to($params['to']); 
    //     $obj->email->subject($params['subject']);
    //     $obj->email->message($params['message']);

    //     // if($params['filepath']!=''){
    //     //   $obj->email->attach($params['filepath']);  
    //     // }
 
    //     $obj->email->set_crlf( "\r\n" );
    //     $response =  $obj->email->send(); 
    //     // print_r($response);
    //     if (!$obj->email->send()) {
    //         // print $mail->ErrorInfo;
    //         echo  "Not Ok";
    //     } else {
    //         echo  "ok";
    //     }

    //      echo $obj->email->print_debugger();
    //      die;
    //     return $obj->email->send(); 
    //     //$obj->email->send(); 
      

    // }

}
