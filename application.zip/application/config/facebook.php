<?php
defined('BASEPATH') or exit('No direct script access allowed');
$config['base_url'] = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$config['base_url'] .= "://" . $_SERVER['HTTP_HOST'];
$config['base_url'] .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);
$config['facebook_app_id'] = '730480257646592';
$config['facebook_app_secret'] = '3d11fbfca33e83954073ddb3b822dbcb	';
$config['facebook_login_type'] = 'web';
$config['facebook_login_redirect_url'] =  "fb/index";
$config['facebook_logout_redirect_url'] = $config['base_url'].'fb/index';
//$config['facebook_permissions'] = array('public_profile', 'email');
$config['facebook_permissions'] = array( 'email');
$config['facebook_graph_version'] = "v2.4";
$config['facebook_auth_on_load'] = "true";