<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class Product extends CI_Model{ 
     
    function __construct() { 
        $this->proTable = 'product_master'; 
        $this->ordTable = 'orders'; 
    } 
     
    /* 
     * Fetch products data from the database 
     * @param id returns a single record if specified, otherwise all records 
     */ 
    public function getRows($id = ''){ 
        $this->db->select('*'); 
        $this->db->from($this->proTable); 
        $this->db->where('status', '1'); 
        if($id){ 
            $this->db->where('product_id', $id); 
            $query  = $this->db->get(); 
            $result = $query->row_array(); 
        }else{ 
            $this->db->order_by('name', 'asc'); 
            $query  = $this->db->get(); 
            $result = $query->result_array(); 
        } 
         
        // return fetched data 
        return !empty($result)?$result:false; 
    } 
     
    /* 
     * Insert data in the database 
     * @param data array 
     */ 
    public function insertOrder($data){ 
        if(empty($data['created'])){ 
            $data['created'] = date("Y-m-d H:i:s"); 
        } 
        if(empty($data['modified'])){ 
            $data['modified'] = date("Y-m-d H:i:s"); 
        } 
        $insert = $this->db->insert($this->ordTable, $data); 
        return $insert?true:false; 
    } 
     
}