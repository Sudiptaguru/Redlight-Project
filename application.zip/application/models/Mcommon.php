<?php
 class Mcommon extends CI_Model {
    function __construct(){
        parent::__construct();
    }
    public function insert($table,$data){
        $this->db->insert($table,$data);     
        return $this->db->insert_id();
    }
    public function batch_insert($table,$data){
        $this->db->insert_batch($table,$data); 
        return 1; 
    }
    public function getDetails($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
        //return $this->db->last_query();
        return $query->result_array(); 
    }
    public function getFullDetails($table){
        $query=$this->db->get($table);
        return $query->result_array();
    }
    public function getRow($table,$condition){
        $this->db->where($condition);        
        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->row_array();    
        }
        return $res;            
    }  

    public function getRowV2($table,$condition,$order_by=''){


        $this->db->where($condition);        
       
        if (isset($order_by)) {
          $this->db->order_by($order_by );          
          $this->db->limit(1 );          
        }
        $query=$this->db->get($table);  
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->row_array();    
        }
        return $res;            
    }  

    public function getRows($table, $condition, $order_by='', $group_by='',$limit = ''){
        $this->db->where($condition);        
        /*if($table=='tbl_package'){
            $this->db->order_by('category_id','asc');          
        }else{
            $this->db->order_by('date_of_creation', 'desc');
        }*/
        if (isset($order_by)) {
          $this->db->order_by($order_by);          
        }
         if (isset($limit)) {
          $this->db->limit($limit);          
        }

        if (isset($group_by)) {
          $this->db->group_by($group_by);          
        }
        
        $query=$this->db->get($table);          
        $res = array();
        if($query->num_rows()>0){ 
            $res = $query->result_array();    
        }

        return $res;            
    }  

    public function checkUser($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get('admins');
        return $query->row_array(); 
    } 
    public function update($table,$condition,$data){
        $this->db->where($condition);
        $this->db->update($table,$data);
        //echo $this->db->last_query();
        return 1;
    }
    public function delete($table,$condition){ 
        $this->db->where($condition);
        $this->db->delete($table);
        return 1;
    }

    public function getsql($sql)
    {
        $query = $this->db->query($sql); 
        return $query->result_array();
    }
    
    public function getTestimonial($condition){
        $this->db->select('*');
        $this->db->from('testimonial');
        $this->db->join('tbl_user', 'tbl_user.user_id = testimonial.user_id','left');
        $this->db->where($condition);
        $query=$this->db->get();
        return $query->result_array();
    }

    public function get_user_template($table,$condition){
        $this->db->where($condition);
        $this->db->order_by('updated_at','desc');
        $query=$this->db->get($table);
        return $query->result_array(); 
    }

    public function select($select='',$table,$condition,$join='',$joinType ,$response = '' ,$fieldname = '' ,$group_by = '')
    {
        if (!empty($select)) {
           $this->db->select($select);
        }else{
            $this->db->select('*');
        }
        
        $this->db->from($table);
        if (isset($join)  && !empty($join)) {
            foreach ($join as $key => $value) {
                $this->db->join($key, $value,$joinType);
            }
        }
        if (!empty($condition)) {
            $this->db->where($condition);
        }
        if (isset($fieldname) && !empty($fieldname)) {
            $this->db->order_by($fieldname,'desc');
        }
        if (isset($group_by) && !empty($group_by)) {
            $this->db->group_by($group_by);
        }   
        $query=$this->db->get();
        //echo $this->db->last_query(); exit();
        if ($response == 'result') {

           return $query->result();
        } 
        elseif($response == 'row') {
           return $query->row_array();
        }
        else{
           return $query->result_array();
        }

    }

    
    public function get($table, $what = null, $condition = null, $limit_start = null, $limit_end = null, $group = null, $condition1 = null, $order_in = null, $order_by = 'DESC', $join = null, $join_type = null,$response = null)
    {
        if (isset($what)) {
            foreach ($what as $key => $value) {
                $this->db->select($value);
            }
        } else {
            $this->db->select('*');
        }

        $this->db->from($table);
        if (isset($condition)) {
            foreach ($condition as $key => $value) {
                $this->db->where($key, $value);
            }
        }
        if (!empty($condition1)) {
            $this->db->where($condition1);
        }

        
        if (isset($join)) {
            foreach ($join as $key => $value) {
               
                $this->db->join($key, $value, $join_type);
                // $this->db->join($key, $value, $join_type[$key]);
            }
        }

        if ($limit_start != null) {
            $this->db->limit($limit_start, $limit_end);
        }
        if ($group != null) {
            $this->db->group_by($group);
        }

        if ($order_in != null) {
            $this->db->order_by($order_in, $order_by);
        }
        $query = $this->db->get();
        // echo $this->db->last_query();die;
        if ($response == 'result') {

            return   $query->result();
        } 
        elseif($response == 'row') {
            return $query->row();
        }
        elseif($response == 'row_array') {
            return $query->row_array();
        }
        else{
            return $query->result_array();
        }
        
    }


  


   

    public function AddActivity($title ,$description ,$created_by)
    {
        $data = array(
                        'activity_title' => $title,
                        'description' => $description,
                        'created_by' => $created_by,
                        'datetime' => date('Y-m-d H:i:m')
                    );
        $this->db->insert('activity_log',$data);     
        return $this->db->insert_id();
    }

    public function selectAll($from, $where = array(), $select = '', $order_by = '', $mode = '', $join = array(), $limit = '', $offset = 0, $group_by = '', $order_by2 = '')
    {
        if ($select) {
           $this->db->select($select);
        } else {
           $this->db->select('*');
        }
        $this->db->from($from);
        if (!empty($join)) {
               foreach ($join as $qry) {
                $this->db->join($qry['table'], $qry['on'], $qry['type']);
            }
        }
        if (!empty($where)) {
           $this->db->where($where);
        }
        if (!empty($group_by)) {
           $this->db->group_by($group_by);
        }
        if ($order_by && $mode) {
           $this->db->order_by($order_by, $mode);
        } else {
           $this->db->order_by($order_by);
        }
          // only for dispatched incident listing
        if($order_by2){
           $this->db->order_by($order_by2, $mode);
        }
        if ($limit) {
           $this->db->limit($limit, $offset);
        }
        return $this->db->get()->result_array();
     }


      public function getCategoryTreeForParentId($parentID = '0') {
          $categories = array();
          $this->db->from('category_master');
          $this->db->where('parent_id', $parentID);
          $this->db->where('status', 1);
          $result = $this->db->get()->result();
          $i =0  ;
          foreach ($result as $mainCategory) {
            $category = array();
            $category['category_id'] = $mainCategory->category_id;
            $category['category'] = $mainCategory->category;
            $category['parent_id'] = $mainCategory->parent_id;
            $category['image'] = $mainCategory->image;
            $category['sub_categories'] = $this->getCategoryTreeForParentId($category['category_id']);
            $categories[$i] = $category;
            $i++;
          }
          return $categories;
    }
      public function getProducts($where,$whereIn="", $key='',$like='')
    {
        $this->db->select('p_m.*');
        $this->db->from('product_master AS p_m');
        $this->db->join('product_category AS p_cat','p_cat.product_id = p_m.product_id ','INNER');
        // $this->db->join('manufacturer_master AS maf_m','maf_m.manufacturerID = p_m.brand ','INNER');
        if (isset($whereIn) && !empty($whereIn)) {
           $this->db->where_in('p_cat.category_id', $whereIn);    
        }
        if (isset($like) && !empty($like))  {
            $this->db->like($key, $like, 'both'); 
        }
        $this->db->where($where);
        $this->db->group_by('p_m.product_id'); 
        $query = $this->db->get();
        return $query->result_array();
    }
     public function getProductsOrderBy($where='',$whereIn,$limit='',$offset='',$order_by='',$order_by_field='',$key='',$like='')
    {
        $fieldname = $order_by_field;
        $this->db->select('p_m.*');
        $this->db->from('product_master AS p_m');
        $this->db->join('product_category AS p_cat','p_cat.product_id = p_m.product_id ','INNER');
        if (isset($whereIn) && !empty($whereIn)) {
          $this->db->where_in('p_cat.category_id', $whereIn);   
        }
       
        if (isset($like) && !empty($like))  {
            $this->db->like($key, $like, 'both'); 
        }
        
        $this->db->where($where);
        $this->db->group_by('p_m.product_id'); 
        $this->db->limit($limit,$offset);
        $this->db->order_by($fieldname,$order_by);
        $query = $this->db->get();
        $data =  $query->result_array();
        if (!empty($data)) {
            $i= 0 ;
            foreach ($data as $key => $value) {
              // $wishlist =  $this->getRow('users_wishlist' ,array('is_active' =>1 ,'user_id'=> $this->session->users['id'] ,'product_id' => $value['porductID']));
              // if (!empty($wishlist)) {
              //     $data[$i]['wishlist'] = 1; 
              // }else{
              //     $data[$i]['wishlist'] = 0; 
              // }

              $image =  $this->getRow('product_images' ,array('status' =>1 ,'product_id'=> $value['product_id']));
              if (!empty($image)) {
                  $data[$i]['image'] = base_url('uploads/product_images/'). $image['image']; 
              }else{
                  $data[$i]['image'] = ''; 
              }                  
              $i++;
            }
        }
        // echo $this->db->last_query();
        return $data;
    }
    public function getProdcutDetails($porductID,$where)
    {
        $this->db->select('p_m.*');
        $this->db->from('product_master AS p_m');
       $this->db->where('product_id',$porductID);            
        $this->db->where($where);
        $query = $this->db->get();
        $product = $query->row_array();
        // //echo print_r($product);die;
        // $join1 = array(
        //                 'product_category AS p_c '=>'category_master.categoryID = p_c.category_id',
                       
        //              ); 
        // $select1 =  "category_master.category,category_master.categoryID,category_master.parentID";
        // $product['product_category'] =  $this->select($select1,'category_master ', $where = array('category_master.is_active ='=> 1 , 'p_c.product_id'=> $porductID),$join1,$joinType ='INNER'  ,'row');
        
        $images =  $this->getDetails('product_images',array('status'=>1 ,  'product_id'=> $porductID));
        if (!empty($images)) {
            $i= 0;
            $product['image'] = base_url('uploads/product_images/').$images[0]['image']; 
            foreach ($images as $key => $image) {
                   $images[$i]['image'] = base_url('uploads/product_images/'). $image['image'];  

                $i++;
            }
        }else{
             $product['image']  = '';
        }

        $product['product_images'] = $images ; 
   
        // $join = array(
        //                 'user_master AS u '=>'u.id = r.user_id',
        //                 'order_user_details AS o_u_d '=>'o_u_d.product_id = r.product_id And o_u_d.order_id = r.order_id',
        //              ); 
        // $select =  "r.*,u.fname,lname,o_u_d.product_name";
        // $product['reviews'] =  $this->select($select,'reviews As r', $where = array('r.is_active ='=> 1 , 'r.product_id'=> $porductID),$join,$joinType ='LEFT'  ,'','r.review_ids');
        // // $product['reviews'] =  $this->getDetails('reviews',array('is_active'=>1 ,  'product_id'=> $porductID));
        // // print_r($product['reviews']);die;
        // if (count($product['reviews']) > 0 ) {
        //    $product['reviews_count'] = count($product['reviews']) ;
        //    $product['rating'] = array_sum(array_map(function($item) { 
        //         return $item['rating']; 
        //     }, $product['reviews']));

        // }else{
        //      $product['reviews_count'] =  0 ;
        //       $product['rating'] = 0;
        // }

        // if (!empty($product)) {
        //       $wishlist =  $this->getRow('users_wishlist' ,array('is_active' =>1 ,'user_id'=> $this->session->users['id'] ,'product_id' => $porductID));
        //       if (!empty($wishlist)) {
        //           $product['wishlist'] = 1; 
        //       }else{
        //           $product['wishlist'] = 0; 
        //       }
        // }

        // $this->getDetails();    

        return   $product;  
    }
    public function getDetailsCart($table,$condition,$order_by='',$where_in=[],$select='*'){
        $this->db->select($select);
        $this->db->where($condition);
        if (isset($order_by)) {
          $this->db->order_by($order_by);          
        }
        if(!empty($where_in))
        {
            $this->db->where($where_in["niddle"].' IN '.$where_in["stack"], NULL, FALSE);
        }
        $this->db->join('product_master ','users_cart.product_id = product_master.product_id','INNER');
        $query=$this->db->get($table);

        $products =   $query->result_array();
        if (!empty($products)) {
            $i= 0 ;
            foreach ($products as $key => $value) {
              $image =  $this->getRow('product_images' ,array('status' =>1 ,'product_id'=> $value['product_id']));
              if (!empty($image)) {
                  $products[$i]['image'] = base_url('uploads/product_images/'). $image['image']; 
              }else{
                  $products[$i]['image'] = ''; 
              }                  
              $i++;
            }
        } 
        return $products; 
    }
    
    public function getNumRows($table,$condition){
        $this->db->where($condition);
        $query=$this->db->get($table);
      //echo $this->db->last_query(); exit();
        $res = array();
        
        return $query->num_rows();            
    }

}
