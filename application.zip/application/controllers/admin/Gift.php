<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gift extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    }else{
      $this->userId=$this->session->admin['user_id'];
    } 
  }

  public function index($value='')
  {
    $data = array();
        if($this->input->post()):

        $postData=$this->input->post();
        // print_r($postData);die;
        if(empty($postData['gift_id'])):
          $insertData = array(
                    // 'user_id'  => $postData['user_id'], 
                    'description'   => $postData['description'], 
                    'store_website_link'  => $postData['store_website_link'], 
                    'price'  => $postData['price'], 
                    'status'    => 1,
                    'created_by'  => $this->userId,
                    
                  );
          $this->mcommon->insert('gift_master',$insertData);
          $this->session->set_flashdata('success_msg','gift Created Successfully!');
        else:
          $insertData = array(
                    // 'user_id'  => $postData['user_id'], 
                    'description'   => $postData['description'], 
                    'store_website_link'  => $postData['store_website_link'],  
                    'price'  => $postData['price'], 
                    'updated_by'  => $this->userId, 
                  );
          $this->mcommon->update('gift_master',
                    array('id' =>$postData['gift_id']),
                    $insertData
                  );
          $this->session->set_flashdata('success_msg','gift Updated Successfully!');
        endif;
        redirect('admin/gift/index','refresh');
      endif;
    $data['giftList']=$this->mcommon->getDetails('gift_master',array('status !='=>3));
    $data['title']='Gift List';
    $data['content']='admin/gift/list';
    $this->_loadView($data);
  }

public function add($id='')
  {
    $data=array();
    if(!empty($id)):
      $data['gift']=$this->mcommon->getRow('gift_master',array('id' =>$id));
      $data['title']='Edit gift';
    else:
      $data['title']='Add gift';
    endif;
    
    $data['content']='admin/gift/add';
    $this->_loadView($data);
  }

  public function view()
  {
    if($this->input->post()):

      $postData=$this->input->post();
      $user=(object)$this->mcommon->getRow('gift_master',
                array(
                  'id' =>$postData['id']
                )
              );
      $html='';
      if (!empty($user)):
          if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
                    // if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    //   $image=base_url("uploads/profile_images/".$user->profile_image);
                    // else:
                    //   $image=base_url("public/no-image.png");
                    // endif;
            $html .='<table id="" class="table table-striped table-bordered"        style="width:100%">
                    <thead>
                      <tr>
                        <th>Particular</th>
                        <th>Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                    
                    <tr>
                      <td><strong>Description.</strong></td>
                      <td> ' .$user->description.' </td>
                    <tr>
                    <tr>
                      <td><strong>Store/Website Link.</strong></td>
                      <td> ' .$user->store_website_link.' </td>
                    <tr>
                    <tr>
                      <td><strong>Price.</strong></td>
                      <td> ' .$user->price.' </td>
                    <tr>
                    
                    <tr>
                      <td><strong>Registered On</strong></td>
                      <td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                    <tr>
                    <tr>
                      <td><strong>User Status</strong></td>
                      <td> ' .$status.' </td>
                    <tr>
                    </tbody>
                    </table>       
                  ';
                  echo $html;
        
      endif;

    endif;
  }
}


