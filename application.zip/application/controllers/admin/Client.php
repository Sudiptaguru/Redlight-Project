<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends MY_Controller {

	public function __construct() {
		parent::__construct();
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}

	public function index($usersId='')
	{
		$data = array();
		$userId=$this->session->admin['user_id'];

			if($this->input->post()):

				$postData=$this->input->post();

				if(empty($postData['clientId'])):
					$insertData = array(
										'name' 	=> $postData['name'], 
										'phone' 	=> $postData['phone'], 
										'email' 		=> $postData['email'], 
										'address' 		=> $postData['address'], 
										'zip_code' 		=> $postData['zip_code'],
										'country' 		=> $postData['country'],
										'state' 		=> $postData['state'],
										'city' 		=> $postData['city'],
										'status' 		=> 1,
										'created_by' 	=> $userId,
										'created_at' 	=> date("Y-m-d H:i:s") 
									);
					$this->mcommon->insert('client_master',$insertData);
					$this->session->set_flashdata('success_msg','User Created Successfully!');
				else:
					$insertData = array(
										'name' 	=> $postData['name'], 
										'phone' 	=> $postData['phone'], 
										'email' 		=> $postData['email'], 
										'address' 		=> $postData['address'], 
										'zip_code' 		=> $postData['zip_code'],
										'country' 		=> $postData['country'],
										'state' 		=> $postData['state'],
										'city' 		=> $postData['city'],
										'updated_at' 	=> date("Y-m-d H:i:s") 
									);
					$this->mcommon->update('client_master',
										array('id' =>$postData['clientId']),
										$insertData
									);
					$this->session->set_flashdata('success_msg','User Updated Successfully!');
				endif;
				redirect('admin/Client/index','refresh');
			endif;
		if(!empty($usersId)):
		
		$whereArray =[
						'cm.user_id'=>$usersId,
						'cm.status !=' =>3
					 ];
		$join[] = ['table' => 'countries_master cm2', 'on' => 'cm2.id = cm.country', 'type' => 'INNER'];
	   $join[] = ['table' => 'states_master sm', 'on' => 'sm.id = cm.state', 'type' => 'INNER'];
	   $join[] = ['table' => 'cities_master cm3', 'on' => 'cm3.id = cm.city', 'type' => 'INNER'];
	   $data['clientList'] = $this->mcommon->selectAll('client_master cm', $whereArray, 'cm.*, cm2.name country_name, cm3.name city_name,sm.name state_name','','',$join);

		endif;
		
		$data['title']='Clients List';
		$data['content']='admin/client/list';
		$this->_loadView($data);
	}

	public function add($id='')
	{
		$data=array();
		if(!empty($id)):
			$data['client']=$this->mcommon->getRow('client_master',array('id' =>$id));
			$data['title']='Edit Client';
		else:
			$data['title']='Add Client';
		endif;
		$data['country']=$this->mcommon->getFullDetails('countries_master');
		
		$data['content']='admin/client/add';
		$this->_loadView($data);
	}
	public function view()
	{
		if($this->input->post()):

			$postData=$this->input->post();
			$user=(object)$this->mcommon->getRow('client_master',
								array(
									'id' =>$postData['id']
								)
							);
			$html='';
			if (!empty($user)):
					if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1 ):
                        $status = 'Active';
                    endif;
                   
            $html .='<table id="" class="table table-striped table-bordered" 				style="width:100%">
                  	<thead>
	                    <tr>
	                      <th>Particulars</th>
	                      <th>Details</th>
	                    </tr>
                  	</thead>
                  	<tbody>
                  	<tr>
                  		<td><strong>Name</strong></td>
                  		<td> ' .$user->name.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Phone No.</strong></td>
                  		<td> ' .$user->phone.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Email</strong></td>
                  		<td> ' .$user->email.'  </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Address</strong></td>
                  		<td> ' .$user->address.' </td>
                  	<tr> 
                  	<tr>
                  		<td><strong>Zip Code</strong></td>
                  		<td> ' .$user->zip_code.' </td>
                  	<tr> 
                  	<tr>
                  		<td><strong>Country</strong></td>
                  		<td> ' .$user->country.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>State</strong></td>
                  		<td> ' .$user->state.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>City</strong></td>
                  		<td> ' .$user->city.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Registered On</strong></td>
                  		<td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>User Status</strong></td>
                  		<td> ' .$status.' </td>
                  	<tr>
                  	</tbody>
                  	</table>       
                  ';
                  echo $html;
				
			endif;

		endif;
	}

}


