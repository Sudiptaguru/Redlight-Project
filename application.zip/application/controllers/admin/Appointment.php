<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    }else{
      $this->userId=$this->session->admin['user_id'];
    } 
  }

  public function index($value='')
  {
    $data = array();
        if($this->input->post()):

        $postData=$this->input->post();
        // print_r($postData);die;
        if(empty($postData['appointment_id'])):
          $insertData = array(
                    'user_id'  => $postData['user_id'],
                    'client_id'  => $postData['client_id'],
                    'appoint_date'  => $postData['appoint_date'], 
                    'start_time'   => $postData['start_time'], 
                    'end_time'  => $postData['end_time'], 
                    'duration'  => $postData['duration'], 
                    'type_of_service'  => $postData['type_of_service'], 
                    'service_amount'  => $postData['service_amount'], 
                    'status'    => 1,
                    'created_by'  => $this->userId
                    
                  );
          $this->mcommon->insert('appointment_master',$insertData);
          $this->session->set_flashdata('success_msg','appointment Created Successfully!');
        else:
          $insertData = array(
                    'user_id'  => $postData['user_id'],
                    'client_id'  => $postData['client_id'],
                    'appoint_date'  => $postData['appoint_date'], 
                    'start_time'   => $postData['start_time'], 
                    'end_time'  => $postData['end_time'], 
                    'duration'  => $postData['duration'], 
                    'type_of_service'  => $postData['type_of_service'], 
                    'service_amount'  => $postData['service_amount'], 
                    // 'image'  => $postData['image'],  
                    'updated_by'  => $this->userId
                  );
          $this->mcommon->update('appointment_master',
                    array('id' =>$postData['appointment_id']),
                    $insertData
                  );
          $this->session->set_flashdata('success_msg','appointment Updated Successfully!');
        endif;
        redirect('admin/appointment/index','refresh');
      endif;
      if(!empty($appointment_id)):
    
    $whereArray =[
            'cm.user_id'=>$appointment_id,
            'cm.status !=' =>3
           ];
    $join[] = ['table' => 'user_master cm2', 'on' => 'cm2.id = cm.user_id', 'type' => 'INNER'];
    $join[] = ['table' => 'client_master cm3', 'on' => 'cm3.id = cm.client_id', 'type' => 'INNER'];
      $data['appointmentList'] = $this->mcommon->selectAll('appointment_master cm', $whereArray, 'cm.*, cm2.name user_name, cm3.name client_name','','',$join);
     // $data['appointmentList'] = $this->mcommon->selectAll('appointment_master cm', $whereArray, 'cm.*, cm2.name client_name ','','',$join);

    // $data['appointmentList']=$this->mcommon->getDetails('appointment_master',array('status !='=>3));
     endif;
    $data['title']='Appointment List';
    $data['content']='admin/appointment/list';
    $this->_loadView($data);
  }


public function add($id='')
  {
    $data=array();
    if(!empty($id)):
      $data['appointment']=$this->mcommon->getRow('appointment_master',array('id' =>$id));
      $data['title']='Edit appointment';
    else:
      $data['title']='Add appointment';
    endif;
    $data['userlist']=$this->mcommon->getDetails('user_master',['status !='=>3,'role_id'=>2]);
    $data['clientlist']=$this->mcommon->getDetails('client_master',['status !='=>3]);
    $data['serviceType']=$this->mcommon->getDetails('service_master',['status !='=>3]);
    $data['content']='admin/appointment/add';
    $this->_loadView($data);
  }

  public function view()
  {
    if($this->input->post()):

      $postData=$this->input->post();
      $user=(object)$this->mcommon->getRow('appointment_master',
                array(
                  'id' =>$postData['id']
                )
              );
      $html='';
      if (!empty($user)):
          if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
                    // if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    //   $image=base_url("uploads/profile_images/".$user->profile_image);
                    // else:
                    //   $image=base_url("public/no-image.png");
                    // endif;
            $html .='<table id="" class="table table-striped table-bordered"        style="width:100%">
                    <thead>
                      <tr>
                        <th>Appointment</th>
                        <th>Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td><strong> User name</strong></td>
                      <td> ' .$user->user_id.' </td>
                    <tr>
                    <tr>
                      <td><strong> Client name</strong></td>
                      <td> ' .$user->client_id.' </td>
                    <tr>
                    
                    <tr>
                      <td><strong> Appoint Date</strong></td>
                      <td> ' .$user->appoint_date.' </td>
                    <tr>
                    <tr>
                      <td><strong>Start Time.</strong></td>
                      <td> ' .$user->start_time.' </td>
                    <tr>
                     <tr>
                      <td><strong>End Time.</strong></td>
                      <td> ' .$user->end_time.' </td>
                    <tr> 
                    <tr>
                      <td><strong>duration.</strong></td>
                      <td> ' .$user->duration.' </td>
                    <tr>
                     <tr>
                      <td><strong>Type of service.</strong></td>
                      <td> ' .$user->type_of_service.' </td>
                    <tr>
                     <tr>
                      <td><strong>Service Amount.</strong></td>
                      <td> ' .$user->service_amount.' </td>
                    <tr>
                    
                    <tr>
                      <td><strong>Created at</strong></td>
                      <td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                    <tr>
                    <tr>
                      <td><strong>User Status</strong></td>
                      <td> ' .$status.' </td>
                    <tr>
                    </tbody>
                    </table>       
                  ';
                  echo $html;
        
      endif;

    endif;
  }
  // public function getUser()
  // {
  //   $html='';
  //   if($this->input->method()=='post'):
  //     $postData= $this->mcommon->getDetails('client_master',['user_id'=>$postData['userId']]);
  //     $html='<option value="">-select client-</option>';
  //     foreach ($data as $key => $value):
  //        $html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
  //        endforeach;
  //        echo $html;
  //        endif;
  // }
  public function getUser()
  {
    $html='';
    if($this->input->method() == 'post'):
      $postData = $this->input->post();
      $data = $this->mcommon->getDetails('client_master',['user_id'=>$postData['userId']]);
      $html ='<option value=" ">-Select client-</option>';
      foreach ($data as $key => $value):
        $html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
      endforeach;
      echo $html;
    endif;
  }


  

}


