<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Appointment extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    }else{
      $this->userId=$this->session->admin['user_id'];
    } 
  }

  public function index($usersId='')
  {
    $data = array();
        if($this->input->post()):

        $postData=$this->input->post();
        // print_r($postData);die;
        if(empty($postData['appointment_id'])):
          $insertData = array(
                    'user_id'  => $postData['user_id'],
                    'client_id'  => $postData['client_id'],
                    'appoint_date'  => $postData['appoint_date'], 
                    'start_time'   => $postData['start_time'], 
                    'end_time'  => $postData['end_time'], 
                    'duration'  => $postData['duration'], 
                    'type_of_service'  => $postData['type_of_service'], 
                    'service_amount'  => $postData['service_amount'], 
                    'status'    => 1,
                    'created_by'  => $this->userId
                    
                  );
          $this->mcommon->insert('appointment_master',$insertData);
          $this->session->set_flashdata('success_msg','appointment Created Successfully!');
        else:
          $insertData = array(
                    'user_id'  => $postData['user_id'],
                    'client_id'  => $postData['client_id'],
                    'appoint_date'  => $postData['appoint_date'], 
                    'start_time'   => $postData['start_time'], 
                    'end_time'  => $postData['end_time'], 
                    'duration'  => $postData['duration'], 
                    'type_of_service'  => $postData['type_of_service'], 
                    'service_amount'  => $postData['service_amount'], 
                    // 'image'  => $postData['image'],  
                    'updated_by'  => $this->userId
                  );
          $this->mcommon->update('appointment_master',
                    array('id' =>$postData['appointment_id']),
                    $insertData
                  );
          $this->session->set_flashdata('success_msg','appointment Updated Successfully!');
        endif;
        redirect('admin/appointment/index','refresh');
      endif;
      // if(!empty($usersId)):
    
        $whereArray =[
                // 'am.user_id'=>$usersId,
                'am.status !=' =>3
               ];
    $join[] = ['table' => 'user_master um', 'on' => 'um.user_id = am.user_id', 'type' => 'LEFT'];
    $join[] = ['table' => 'client_master cm', 'on' => 'cm.id = am.client_id', 'type' => 'LEFT'];
    $join[] = ['table' => 'service_master sm', 'on' => 'sm.id = am.type_of_service', 'type' => 'LEFT'];
      $data['appointmentList'] = $this->mcommon->selectAll('appointment_master am', $whereArray, 'am.*, um.first_name user_name, cm.name client_name, sm.service_name type_of_service','','',$join);
      // echo $this->db->last_query();die;
    
    $data['title']='Appointment List';
    $data['content']='admin/appointment/list';
    $this->_loadView($data);
    
  }


public function add($id='')
  {
    $data=array();
    if(!empty($id)):
      $data['appointment']=$this->mcommon->getRow('appointment_master',array('id' =>$id));
      // print_r($data);die;
      $data['title']='Edit appointment';
    else:
      $data['title']='Add appointment';
    endif;
    $data['userlist']=$this->mcommon->getDetails('user_master',['status !='=>3,'role_id'=>2]);
    $data['clientlist']=$this->mcommon->getDetails('client_master',['status !='=>3]);
    $data['serviceType']=$this->mcommon->getDetails('service_master',['status !='=>3]);
    $data['content']='admin/appointment/add';
    $this->_loadView($data);
  }

  public function view()
  {
    if($this->input->post()):

      $postData=$this->input->post();
      // print_r($postData);die;
      $whereArray =[
                    'am.id' =>$postData['id'],
                    'am.status !=' =>3
                   ];
      $join[] = ['table' => 'user_master um', 'on' => 'um.user_id = am.user_id', 'type' => 'LEFT'];
      $join[] = ['table' => 'client_master cm', 'on' => 'cm.id = am.client_id', 'type' => 'LEFT'];
      $join[] = ['table' => 'service_master sm', 'on' => 'sm.id = am.type_of_service', 'type' => 'LEFT'];
        $user =(object) $this->mcommon->selectAll('appointment_master am', $whereArray, 'am.*, um.first_name user_name, cm.name client_name, sm.service_name type_of_service','','',$join);
        // print_r($user);die;
      $html='';
      if (!empty($user)):
          if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
      

                    // if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    //   $image=base_url("uploads/profile_images/".$user->profile_image);
                    // else:
                    //   $image=base_url("public/no-image.png");
                    // endif;

      
      // print_r($user);die;

            $html .='<table id="" class="table table-striped table-bordered"        style="width:100%">
                    <thead>
                      <tr>
                        <th>Appointment</th>
                        <th>Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    <tr>
                      <td><strong> User name</strong></td>
                      <td> ' .$user->user_name.' </td>
                    <tr>
                    <tr>
                      <td><strong> Client name</strong></td>
                      <td> ' .$user->client_name.' </td>
                    <tr>

                    <tr>
                      <td><strong> Appoint Date</strong></td>
                      <td> ' .$user->appoint_date.' </td>
                    <tr>
                    <tr>
                      <td><strong>Start Time.</strong></td>
                      <td> ' .$user->start_time.' </td>
                    <tr>
                     <tr>
                      <td><strong>End Time.</strong></td>
                      <td> ' .$user->end_time.' </td>
                    <tr> 
                    <tr>
                      <td><strong>duration.</strong></td>
                      <td> ' .$user->duration.' </td>
                    <tr>
                     <tr>
                      <td><strong>Type of service.</strong></td>
                      <td> ' .$user->type_of_service.' </td>
                    <tr>
                     <tr>
                      <td><strong>Service Amount.</strong></td>
                      <td> ' .$user->service_amount.' </td>
                    <tr>
                    
                    <tr>
                      <td><strong>Created at</strong></td>
                      <td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                    <tr>
                    <tr>
                      <td><strong>User Status</strong></td>
                      <td> ' .$status.' </td>
                    <tr>
                    </tbody>
                    </table>       
                  ';
                  echo $html;
      endif;

    endif;
  }
  public function getClient()
  {
    $html='';
    if($this->input->method()=='post'):
      $postData = $this->input->post();
      $data = $this->mcommon->getDetails('client_master',['user_id'=>$postData['userId']]);
      $html='<option value="">-select client-</option>';
      foreach ($data as $key => $value):
         $html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
      endforeach;
      echo $html;
    endif;
  }
  

}


