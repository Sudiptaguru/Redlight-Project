<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index() { 		
		if ($this->input->post()) { 
			/* Set the validation rules */
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$this->_load_login_view();
			} else {
				$email = $this->input->post('email', true);
				$password = $this->input->post('password', true);
				$userdata = $this->mcommon->getRow('user_master',
										array(
											'email' =>$email,
											'password'=>md5($password)
										)
									); 
				if (empty($userdata)) {
					$this->session->set_flashdata('error_msg', 'Invalid credential');
					$this->_load_login_view();
				} else { 
					$this->session->set_userdata('admin', $userdata);
					redirect('admin/dashboard','refresh');
				}	
			}
		} else {			
			if($this->is_logged_in_admin()){
			redirect('admin/dashboard','refresh');	
			}else{
			$this->_load_login_view();	
			}
		}
	}
	private function _load_login_view() {
		$data = array();
		$data['content'] = 'admin/login';
		$this->load->view('admin/layouts/login', $data);
	}


	public function getState()
	{
		$html='';
		if($this->input->method() == 'post'):
			$postData = $this->input->post();
			$data = $this->mcommon->getDetails('states_master' ,['country_id'=>$postData['countryId']]);
			$html ='<option value="">-Select State-</option>';
			foreach ($data as $key => $value):
				$html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
			endforeach;
			echo $html;
		endif;
	}
	public function getCity()
	{
		$html='';
		if($this->input->method() == 'post'):
			$postData = $this->input->post();
			$data = $this->mcommon->getDetails('cities_master',['state_id'=>$postData['stateId']]);
			$html ='<option value="">-Select City-</option>';
			foreach ($data as $key => $value):
				$html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
			endforeach;
			echo $html;
		endif;
	}

}
