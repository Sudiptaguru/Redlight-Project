<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}

	public function index($value='')
	{
		$data = array();
		

		$data['content']='';
		$this->_loadView($data);
	}

	/*common change status*/
	 public function changeStatus(){
	 	$postData=$this->input->post();
	 	if (!empty($postData)) {
	     	$isUpdate = $this->mcommon->update($postData['table'], 
	     					[$postData['indexKey'] => $postData['id']], 
	     					['status' => $postData['status']]
	     				);
		    if($isUpdate){
		        $response = array('status' => array('error_code' => 0, 'message' => 'Request successfully done'));
		    }else{
		     	$response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'));
		    }
	  	}else{
	   		$response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'));
	   	}

	  exit(json_encode($response));
	}


}


