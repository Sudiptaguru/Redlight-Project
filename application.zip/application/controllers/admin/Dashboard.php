<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}

	public function index($value='')
	{
		$data = array();
		$data['title']='Dashboard';

		$data['users'] = $this->mcommon->getRows('user_master',array('role_id !=' =>1,'status !='=>3));

		$condition =  array('u_l.status !=' =>3 ,'u_l.payment_status'=> 'paid' );
    	$join = array(
                    ' user_master AS u_m' => ' u_l.user_id = u_m.user_id ',
                    ' states' => ' u_l.state = states.state_code ',
                    );


    	$data['clients'] = $this->mcommon->getRows('client_master',array('status !='=>3));

		$condition =  array('u_l.status !=' =>3 ,'u_l.payment_status'=> 'paid' );
    	$join = array(
                    ' client_master AS u_m' => ' u_l.user_id = u_m.user_id ',
                    ' states' => ' u_l.state = states.state_code ',
                    );

    	$data['subscription'] = $this->mcommon->getRows('subscription',array('status !='=>3));

		$condition =  array('u_l.status !=' =>3 ,'u_l.payment_status'=> 'paid' );
    	$join = array(
                    ' subscription AS u_m' => ' u_l.user_id = u_m.user_id ',
                    ' states' => ' u_l.state = states.state_code ',
                    );

    	// $data['lead_list'] =  $this->mcommon->select('u_l.*,u_m.first_name,u_m.last_name,states.state AS state_name', 'user_leads As u_l',$condition , $join,'LEFT');

    	// $condition =  array(  
     //                          'user_orders.payment_status'=>'Paid',
     //                          'trancation_tbl.trancation_type' =>'order'  
     //                        );
	    // $join = array(
	    //         'order_transaction_details As trancation_tbl' => 'trancation_tbl.order_id = user_orders.orderid',
	    //         'user_master'                                =>  'user_orders.customer_id  = user_master.user_id'
	    //         );
	    //  $select = array('user_orders.*,trancation_tbl.payment_id,trancation_tbl.gateway_id As payment_customer_id,trancation_tbl.type' ,'user_master.first_name','user_master.last_name');
	    //  $data['orders'] =  $this->mcommon->get('user_orders As user_orders',$select ,$condition ,"","","","","user_orders.order_id","DESC",$join,'INNER' );
	    // $condition =  array(  
                           
     //                            'trancation_tbl.trancation_type' =>'subscription'   
     //                          );
    	// $join = array(
     //        ' subscription_packages As sub_pack' => ' u_sub.plan_id = sub_pack.subscription_id',
     //        'order_transaction_details As trancation_tbl' => 'trancation_tbl.order_id = u_sub.id ',
     //        'user_master'                                =>  'u_sub.user_id  = user_master.user_id'
     //        );
    	// $select = array('u_sub.*,plan_name,title,trancation_tbl.payment_id,trancation_tbl.gateway_id As customer_id,trancation_tbl.payment_status','user_master.first_name','user_master.last_name');
   		//  $data['active_membership'] =  $this->mcommon->get('users_subscription As u_sub',$select ,$condition ,"","","","","u_sub.id","DESC",$join,'INNER' );

   		//  $data['payment'] = $this->mcommon->getsql('SELECT sum(amount) As amount FROM order_transaction_details WHERE status =1');
   		 // print_r($data['payment']);
		

		$data['content']='admin/dashboard/list';
		$this->_loadView($data);
	}

	/*common change status*/
	 public function changeStatus(){
	 	$postData=$this->input->post();
	 	if (!empty($postData)) {
	     	$isUpdate = $this->mcommon->update($postData['table'], 
	     					[$postData['indexKey'] => $postData['id']], 
	     					['status' => $postData['status']]
	     				);
		    if($isUpdate){
		        $response = array('status' => array('error_code' => 0, 'message' => 'Request successfully done'));
		    }else{
		     	$response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'));
		    }
	  	}else{
	   		$response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'));
	   	}

	  exit(json_encode($response));
	}


}


