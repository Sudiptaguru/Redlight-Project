<?php
defined( 'BASEPATH' )OR exit( 'No direct script access allowed' );
class Home extends MY_Controller {

    function __construct() {
		parent::__construct();
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}
	public function index(){
    
	}
	public function starteractivity($id=''){
		$data=array();

    if ($this->input->post()) {
      $postData =  $this->input->post() ;
      $i = 0 ;
      foreach ($postData['id'] as $key => $value) {
          $updataData = array(
                              'title' =>$postData['title'][$i] ,
                              'description' =>$postData['description'][$i] ,
                              'updated_on' => date('Y-m-d H:i:m')
                            ); 
          $this->mcommon->update('starter_activity',array('id' => $value), $updataData);
        $i++;
      }
    }
		$data['starteractivity']=$this->mcommon->getRows('starter_activity',array('status' =>1));
		$data['title']='Home Starter Page';
		$data['content']='admin/home/starteractivity';
		$this->_loadView($data);
	}


  public function leadgeneration()
  {

    $data=array();

    if ($this->input->post()) {
      $postData =  $this->input->post() ;
      $updataData = array(
                          'title' =>$postData['title'] ,
                          'description' =>$postData['description'] ,
                          'updated_on' => date('Y-m-d H:i:m')
                        ); 
      $this->mcommon->update('home_cms',array('id' => $postData['id']), $updataData);
        
    }
    $data['leadgeneration']=$this->mcommon->getRow('home_cms',array('status' =>1,'id'=>1));
    $data['title']='Home lead Generation';
    $data['content']='admin/home/leadgeneration';
    $this->_loadView($data);
  }

  public function Network()
  {

    $data=array();

    if ($this->input->post()) {
      $postData =  $this->input->post() ;
      $updataData = array(
                          'title' =>$postData['title'] ,
                          'description' =>$postData['description'] ,
                          'updated_on' => date('Y-m-d H:i:m')
                        ); 
      $this->mcommon->update('home_cms',array('id' => $postData['id']), $updataData);
        
    }
    $data['leadgeneration']=$this->mcommon->getRow('home_cms',array('status' =>1,'id'=>2));
    $data['title']='Home  Network';
    $data['content']='admin/home/network';
    $this->_loadView($data);
  }

  public function calculator()
  {

    $data=array();

    if ($this->input->post()) {
      $postData =  $this->input->post() ;
      $updataData = array(
                          'title' =>$postData['title'] ,
                          'description' =>$postData['description'] ,
                          'updated_on' => date('Y-m-d H:i:m')
                        ); 
      $this->mcommon->update('home_cms',array('id' => $postData['id']), $updataData);
        
    }
    $data['leadgeneration']=$this->mcommon->getRow('home_cms',array('status' =>1,'id'=>3));
    $data['title']='Home Calcuator';
    $data['content']='admin/home/calculator';
    $this->_loadView($data);
  }
  public function store()
  {

    $data=array();

    if ($this->input->post()) {
      $postData =  $this->input->post() ;
      $updataData = array(
                          'title' =>$postData['title'] ,
                          'description' =>$postData['description'] ,
                          'link1' =>$postData['link1'] ,
                          'link2' =>$postData['link2'] ,
                          'updated_on' => date('Y-m-d H:i:m')
                        ); 
      $this->mcommon->update('home_cms',array('id' => $postData['id']), $updataData);
        
    }
    $data['leadgeneration']=$this->mcommon->getRow('home_cms',array('status' =>1,'id'=>4));
    $data['title']='Home Store';
    $data['content']='admin/home/store';
    $this->_loadView($data);
  }
	public function view()
	{
		if($this->input->post()):

			$postData=$this->input->post();
			$help=(object)$this->mcommon->getRow('help',
								array(
									'help_id' =>$postData['id']
								)
							);
			$html='';
			if (!empty($help)):
					if ($help->status == 0):
                        $status = 'Inactive';
                    elseif ($help->status == 1):
                        $status = 'Active';
                    endif;
            $html .='<table id="" class="table table-striped table-bordered" 				style="width:100%">
                  	<thead>
	                    <tr>
	                      <th>Particulars</th>
	                      <th>Details</th>
	                    </tr>
                  	</thead>
                  	<tbody>
                  	<tr>
                  		<td><strong>Title</strong></td>
                  		<td> ' .$help->title.'</td>
                  	<tr>
                  	<tr>
                  		<td><strong>Description</strong></td>
                  		<td> ' .$help->description.' </td>
                  	<tr> 
                  	<tr>
                  		<td><strong>Created On</strong></td>
                  		<td> ' .date("d-m-Y",strtotime($help->created_on)).' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Content Status</strong></td>
                  		<td> ' .$status.' </td>
                  	<tr>
                  	</tbody>
                  	</table>       
                  ';
                  echo $html;
				
			endif;

		endif;
	}
}
?>