<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends MY_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}
		
	}
    public function changepassword(){
		$this->_load_view();
	}
	public function changeuserpasswd(){

		$this->form_validation->set_error_delimiters('<span class="error">', '</span>');
		$this->form_validation->set_rules('oldpassw','Old password','trim|required');
		$this->form_validation->set_rules('newpassw','New password','trim|required');
		$this->form_validation->set_rules('confpassw','Confirm password','trim|required');
		if($this->form_validation->run()== FALSE){
			$this->_load_view();
		}else{
			$admin_user=$this->session->userdata('admin');
            $oldpassw=$this->input->post('oldpassw');
			$enc_oldpassw=md5($oldpassw);
			$newpassw=$this->input->post('newpassw');
			$enc_newpassw=md5($newpassw);
			$confpassw=$this->input->post('confpassw');
			if($enc_oldpassw!=$admin_user['password']){
				$this->session->set_flashdata('error_msg','Old password is not correct');
				$this->_load_view();
			}else{
				if($newpassw!=$confpassw){
				$this->session->set_flashdata('error_msg','New password does not match with confirm password');
				$this->_load_view();	
				}else{
				$data=array('password'=>$enc_newpassw);
				$condition=array('user_id'=>$admin_user['user_id']);	
				//print_r($admin_user);die;
				$this->mcommon->update('user_master',$condition,$data);	
				$this->session->set_flashdata('success_msg','Password has been changed successfully');
				redirect('admin/settings/changepassword','refersh'); 
				}
			}
		}
	}
	public function changeprofile(){
		$admin=$this->session->userdata('admin'); 

		// echo "<pre>";print_r($admin);exit();

		$data=$this->mcommon->getRow('user_master',['user_id'=>$this->session->admin['user_id']]);
		$this->_load_profile_view($data);
	}
	public function changeuserprofile(){
		$this->form_validation->set_error_delimiters('<span class="error">', '</span>');
		$admin=$this->session->userdata('admin');
		$this->form_validation->set_rules('first_name','First Name','trim|required');
		$this->form_validation->set_rules('last_name','Last Name','trim|required');
		$this->form_validation->set_rules('mobile','Mobile No','trim|required');
		if($this->form_validation->run()== FALSE){
			$data=$this->madmin->user_details($admin['id']);
			$this->_load_profile_view($data);
		}else{
				
			$udata['first_name']   = $this->input->post('first_name');
			$udata['last_name']    = $this->input->post('last_name');
			$udata['mobile']       = $this->input->post('mobile');			
				
			if(!empty($_FILES['imgInp']['name'])){				
			
				$img=$this->image_upload();
				if($img['status']==1){
					$udata['profile_image']	= $img['result'];					
				}else{
					$this->session->set_flashdata('error_msg',$img['result']);
					redirect('admin/settings/changeprofile','refersh'); 	
				}	
			}

			$condition=array('id'=>$admin['id']);
			$this->madmin->update($condition,$udata);
			$data=$this->madmin->user_details($admin['id']);
			$this->session->set_userdata('admin',$data);
			$this->session->set_flashdata('success_msg','Profile updated successfully');
			redirect('admin/settings/changeprofile','refersh'); 
		}
	}	
	public function settings(){
		$this->_load_setting_view();
	}
	public function updateSettings(){				
		$this->form_validation->set_rules('link1','Link1','required');		
		$this->form_validation->set_rules('link2','Link2','required');	
		$this->form_validation->set_rules('link3','link3','required');		
		$this->form_validation->set_rules('link4','link4','required');			
		if($this->form_validation->run()== FALSE){						
			$this->_load_setting_view();
		}else{			
			
			$udata 	= $this->input->post();			
			$this->madmin->update_setting($udata);			
			$this->session->set_flashdata('success_msg','Settings has been updated successfully');
			redirect('admin/settings/settings','refersh'); 								
		}
	}					
	private function _load_setting_view(){
		$data = array();		
		$data['settings']	= $this->madmin->setting_value();	
		//print_r($data['settings']); exit();	
		$data['content'] 	= 'admin/settings';
		$this->load->view('admin/layouts/index',$data);
	}	
	private function image_upload(){
		$img 						= 'imgInp';
		$config['upload_path'] 		= './public/uploads/profile_image/';
		$config['allowed_types'] 	= 'gif|jpg|png|jpeg';
		//$config['max_size']			= '100';
		//$config['max_width']  		= '1024';
		//$config['max_height']  		= '768';
		$config['encrypt_name']  	= true;
		$this->load->library('upload', $config);
		if ( ! $this->upload->do_upload($img)){
			$message 	= array('result' => $this->upload->display_errors(),'status'=>0);
		}else{ 
			$data 		= array('upload_data' => $this->upload->data());
			$message 	= array('result' => $data['upload_data']['file_name'],'status'=>1);
		}
		return $message;
	}
    private function _load_view(){
		$data = array();
		$admin_user=$this->session->userdata('admin');
		$data['user']=$admin_user;
		$data['content'] = 'admin/changepassword';
		$this->load->view('admin/layouts/index',$data);
	}
	private function _load_profile_view($user) {

		$data = array();
		$data['user']=$user;

		//echo "<pre>";print_r($user);exit();

		$data['content'] = 'admin/changeprofile';
		$this->load->view('admin/layouts/index',$data);
	}
}
