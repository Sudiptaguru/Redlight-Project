<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}

	public function index($value='')
	{
		$data = array();
		$roleId=$this->session->admin['role_id'];

			if($this->input->post()):

				$postData=$this->input->post();

				if(empty($postData['userId'])):
					$insertData = array(
										'first_name' 	=> $postData['first_name'], 
										'last_name' 	=> $postData['last_name'], 
										'phone_number' 	=> $postData['phone_number'], 
										'email' 		=> $postData['email'], 
										'address' 		=> $postData['address'], 
										'about_us' 		=> $postData['about_us'],
										'status' 		=> 1,
										'created_by' 	=> $roleId,
										'created_on' 	=> date("Y-m-d H:i:s") 
									);
					$this->mcommon->insert('user_master',$insertData);
					$this->session->set_flashdata('success_msg','User Created Successfully!');
				else:
					$insertData = array(
										'first_name' 	=> $postData['first_name'], 
										'last_name' 	=> $postData['last_name'], 
										'phone_number' 	=> $postData['phone_number'], 
										'email' 		=> $postData['email'], 
										'address' 		=> $postData['address'], 
										'about_us' 		=> $postData['about_us'],
										'updated_on' 	=> date("Y-m-d H:i:s") 
									);
					$this->mcommon->update('user_master',
										array('user_id' =>$postData['userId']),
										$insertData
									);
					$this->session->set_flashdata('success_msg','User Updated Successfully!');
				endif;
				redirect('admin/users/index','refresh');
			endif;
		$data['userList']=$this->mcommon->getDetails('user_master',array('role_id !=' =>1,'status !='=>3));
		$data['title']='Users List';
		$data['content']='admin/user/list';
		$this->_loadView($data);
	}

	public function add($id='')
	{
		$data=array();
		if(!empty($id)):
			$data['user']=$this->mcommon->getRow('user_master',array('user_id' =>$id));
			$data['title']='Edit User';
		else:
			$data['title']='Add User';
		endif;
		
		$data['content']='admin/user/add';
		$this->_loadView($data);
	}

	public function view()
	{
		if($this->input->post()):

			$postData=$this->input->post();
			$user=(object)$this->mcommon->getRow('user_master',
								array(
									'user_id' =>$postData['id']
								)
							);
			$html='';
			if (!empty($user)):
					if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
                    if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    	$image=base_url("uploads/profile_images/".$user->profile_image);
                    else:
                    	$image=base_url("public/no-image.png");
                    endif;
            $html .='<table id="" class="table table-striped table-bordered" 				style="width:100%">
                  	<thead>
	                    <tr>
	                      <th>Particulars</th>
	                      <th>Details</th>
	                    </tr>
                  	</thead>
                  	<tbody>
                  	<tr>
                  		<td><strong>Profile Image</strong></td>
                  		<td><img style="height:150px;" src="'.$image.'"></td>
                  	<tr> 
                  	<tr>
                  		<td><strong>Name</strong></td>
                  		<td> ' .$user->first_name.' '.$user->last_name .' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Phone No.</strong></td>
                  		<td> ' .$user->phone_number.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Email</strong></td>
                  		<td> ' .$user->email.'  </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Logged In With</strong></td>
                  		<td> ' .$user->logged_via.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Address</strong></td>
                  		<td> ' .$user->address.' </td>
                  	<tr> 
                  	<tr>
                  		<td><strong>About User</strong></td>
                  		<td> ' .$user->about_us.' </td>
                  	<tr> 
                  	
                  	<tr>
                  		<td><strong>Registered On</strong></td>
                  		<td> ' .date("d-m-Y",strtotime($user->created_on)).' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>User Status</strong></td>
                  		<td> ' .$status.' </td>
                  	<tr>
                  	</tbody>
                  	</table>       
                  ';
                  echo $html;
				
			endif;

		endif;
	}


}


