<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Law extends MY_Controller {

	public function __construct() {
		parent::__construct();
		
		if(!$this->is_logged_in_admin()){
			redirect(base_url('admin/index'));
		}	
	}

	public function index($value='')
	{
		// $data = array();
		// $userId=$this->session->admin['user_id'];

		// 	if($this->input->post()):

		// 		$postData=$this->input->post();

		// 		if(empty($postData['userId'])):
		// 			$insertData = array(
		// 								'email' 		=> $postData['email'],
		// 								'subject' 		=> $postData['subject'],
		// 								'message' 		=> $postData['message'], 
		// 								'status' 		=> 1,
		// 								'created_by' 	=> $userId,
		// 								'created_on' 	=> date("Y-m-d H:i:s") 
		// 							);
		// 			$this->mcommon->insert('lawyer_assistance_master',$insertData);
		// 			$this->session->set_flashdata('success_msg','User Created Successfully!');
		// 		else:
		// 			$insertData = array(
		// 								'email' 		=> $postData['email'],
		// 								'subject' 		=> $postData['subject'],
		// 								'message' 		=> $postData['message'], 
		// 								'updated_on' 	=> date("Y-m-d H:i:s") 
		// 							);
		// 			$this->mcommon->update('lawyer_assistance_master',
		// 								array('id' =>$postData['userId']),
		// 								$insertData
		// 							);
		// 			$this->session->set_flashdata('success_msg','User Updated Successfully!');
		// 		endif;
		// 		redirect('admin/Law/index','refresh');
		// 	endif;
		$data['lawList']=$this->mcommon->getDetails('lawyer_assistance_master',array('user_id !=' =>1,'status !='=>3));
		$data['title']='Lawyers List';
		$data['content']='admin/law/list';
		$this->_loadView($data);
	}

	// public function add($id='')
	// {
	// 	$data=array();
	// 	if(!empty($id)):
	// 		$data['law']=$this->mcommon->getRow('lawyer_assistance_master',array('id' =>$id));
	// 		$data['title']='Edit Lawyer';
	// 	else:
	// 		$data['title']='Add Lawyer';
	// 	endif;
		
	// 	$data['content']='admin/law/add';
	// 	$this->_loadView($data);
	// }

	public function view()
	{
		if($this->input->post()):

			$postData=$this->input->post();
			$law=(object)$this->mcommon->getRow('lawyer_assistance_master',
								array(
									'id' =>$postData['id']
								)
							);
			$html='';
			if (!empty($law)):
					if ($law->status == 0):
                        $status = 'Inactive';
                    elseif ($law->status == 1):
                        $status = 'Active';
                    endif;
            $html .='<table id="" class="table table-striped table-bordered" 				style="width:100%">
                  	<thead>
	                    <tr>
	                      <th>Particulars</th>
	                      <th>Details</th>
	                    </tr>
                  	</thead>
                  	<tbody>
                  	<tr>
                  		<td><strong>Email</strong></td>
                  		<td> ' .$law->email.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Subject.</strong></td>
                  		<td> ' .$law->subject.' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Message</strong></td>
                  		<td> ' .$law->message.'  </td>
                  	<tr>
                  	
                  	<tr>
                  		<td><strong>Registered On</strong></td>
                  		<td> ' .date("d-m-Y",strtotime($law->created_on)).' </td>
                  	<tr>
                  	<tr>
                  		<td><strong>Lawyer Assistance Status</strong></td>
                  		<td> ' .$status.' </td>
                  	<tr>
                  	</tbody>
                  	</table>       
                  ';
                  echo $html;
				
			endif;

		endif;
	}


}


