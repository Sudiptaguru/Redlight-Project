<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    }else{
      $this->userId=$this->session->admin['user_id'];
    } 
  }

  public function index($value='')
  {
    $data = array();
        if($this->input->post()):

        $postData=$this->input->post();
        // print_r($postData);die;
        if(empty($postData['service_id'])):
          $insertData = array(
                    'service_name'  => $postData['service_name'], 
                    'description'   => $postData['description'], 
                    // 'image'  => $postData['image'], 
                    'status'    => 1,
                    'created_by'  => $this->userId,
                    
                  );
          $this->mcommon->insert('service_master',$insertData);
          $this->session->set_flashdata('success_msg','service Created Successfully!');
        else:
          $insertData = array(
                    'service_name'  => $postData['service_name'], 
                    'description'   => $postData['description'], 
                    // 'image'  => $postData['image'],  
                    'updated_by'  => $this->userId, 
                  );
          $this->mcommon->update('service_master',
                    array('id' =>$postData['service_id']),
                    $insertData
                  );
          $this->session->set_flashdata('success_msg','service Updated Successfully!');
        endif;
        redirect('admin/service/index','refresh');
      endif;
    $data['serviceList']=$this->mcommon->getDetails('service_master',array('status !='=>3));
    $data['title']='Service List';
    $data['content']='admin/service/list';
    $this->_loadView($data);
  }

public function add($id='')
  {
    $data=array();
    if(!empty($id)):
      $data['service']=$this->mcommon->getRow('service_master',array('id' =>$id));
      $data['title']='Edit service';
    else:
      $data['title']='Add service';
    endif;
    
    $data['content']='admin/service/add';
    $this->_loadView($data);
  }

  public function view()
  {
    if($this->input->post()):

      $postData=$this->input->post();
      $user=(object)$this->mcommon->getRow('service_master',
                array(
                  'id' =>$postData['id']
                )
              );
      $html='';
      if (!empty($user)):
          if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
                    // if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    //   $image=base_url("uploads/profile_images/".$user->profile_image);
                    // else:
                    //   $image=base_url("public/no-image.png");
                    // endif;
            $html .='<table id="" class="table table-striped table-bordered"        style="width:100%">
                    <thead>
                      <tr>
                        <th>Service</th>
                        <th>Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                    <tr>
                      <td><strong>service Name</strong></td>
                      <td> ' .$user->service_name.' </td>
                    <tr>
                    <tr>
                      <td><strong>Description.</strong></td>
                      <td> ' .$user->description.' </td>
                    <tr>
                    
                    
                    <tr>
                      <td><strong>Registered On</strong></td>
                      <td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                    <tr>
                    <tr>
                      <td><strong>Service Status</strong></td>
                      <td> ' .$status.' </td>
                    <tr>
                    </tbody>
                    </table>       
                  ';
                  echo $html;
        
      endif;

    endif;
  }
}


