<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    }else{
      $this->userId=$this->session->admin['user_id'];
    } 
  }

  public function index($value='')
  {
    $data = array();
        if($this->input->post()):

        $postData=$this->input->post();
        // print_r($postData);die;
        if(empty($postData['subscription_id'])):
          $insertData = array(
                    'plan_name'  => $postData['plan_name'], 
                    'term'   => $postData['term'], 
                    'amount'  => $postData['amount'], 
                    'status'    => 1,
                    'created_by'  => $this->userId,
                    
                  );
          $this->mcommon->insert('subscription',$insertData);
          $this->session->set_flashdata('success_msg','subscription Created Successfully!');
        else:
          $insertData = array(
                    'plan_name'  => $postData['plan_name'], 
                    'term'   => $postData['term'], 
                    'amount'  => $postData['amount'],  
                    'updated_by'  => $this->userId, 
                  );
          $this->mcommon->update('subscription',
                    array('id' =>$postData['subscription_id']),
                    $insertData
                  );
          $this->session->set_flashdata('success_msg','subscription Updated Successfully!');
        endif;
        redirect('admin/subscription/index','refresh');
      endif;
    $data['subscriptionList']=$this->mcommon->getDetails('subscription',array('status !='=>3));
    $data['title']='Subscription List';
    $data['content']='admin/subscription/list';
    $this->_loadView($data);
  }

public function add($id='')
  {
    $data=array();
    if(!empty($id)):
      $data['subscription']=$this->mcommon->getRow('subscription',array('id' =>$id));
      $data['title']='Edit subscription';
    else:
      $data['title']='Add subscription';
    endif;
    
    $data['content']='admin/subscription/add';
    $this->_loadView($data);
  }

  public function view()
  {
    if($this->input->post()):

      $postData=$this->input->post();
      $user=(object)$this->mcommon->getRow('subscription',
                array(
                  'id' =>$postData['id']
                )
              );
      $html='';
      if (!empty($user)):
          if ($user->status == 0):
                        $status = 'Inactive';
                    elseif ($user->status == 1):
                        $status = 'Active';
                    endif;
                    // if(!empty($user->profile_image) && file_exists(getcwd().'/uploads/profile_images/'.$user->profile_image)):

                    //   $image=base_url("uploads/profile_images/".$user->profile_image);
                    // else:
                    //   $image=base_url("public/no-image.png");
                    // endif;
            $html .='<table id="" class="table table-striped table-bordered"        style="width:100%">
                    <thead>
                      <tr>
                        <th>Subscription</th>
                        <th>Details</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                    <tr>
                      <td><strong>Plan Name</strong></td>
                      <td> ' .$user->plan_name.' </td>
                    <tr>
                    <tr>
                      <td><strong>Term.</strong></td>
                      <td> ' .$user->term.' </td>
                    <tr>
                    <tr>
                      <td><strong>Amount</strong></td>
                      <td> $' .$user->amount.'  </td>
                    <tr>
                    
                    <tr>
                      <td><strong>Registered On</strong></td>
                      <td> ' .date("d-m-Y",strtotime($user->created_at)).' </td>
                    <tr>
                    <tr>
                      <td><strong>Subscription Status</strong></td>
                      <td> ' .$status.' </td>
                    <tr>
                    </tbody>
                    </table>       
                  ';
                  echo $html;
        
      endif;

    endif;
  }
}


