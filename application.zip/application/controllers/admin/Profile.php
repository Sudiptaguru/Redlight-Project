<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends MY_Controller {

  public function __construct() {
    parent::__construct();
    
    if(!$this->is_logged_in_admin()){
      redirect(base_url('admin/index'));
    } 
  }

  public function index($value='')
  {
    $data['user'] = $this->mcommon->getRow('user_master',['user_id'=>$this->session->admin['user_id']]);
    $data['content']='admin/profile/update';
    $this->_loadView($data);
  }

  public function profileUpdate()
  {
    if($this->input->method() == 'post'):

      $postData = $this->input->post();
      if(!empty($postData['old_file'])):
            $old_file=$postData['old_file'];
          else:
            $old_file='';
          endif;
      $files = $_FILES;
      $insertData = array(
                    'first_name'  => $postData['first_name'], 
                    'last_name'   => $postData['last_name'],
                    'phone_number'   => $postData['phone_number'], 
                    'address'   => $postData['address'],
                    'updated_on'  => date("Y-m-d H:i:s") 
                  );
          if(!empty($files) && $files['file']['name'] != ''):
                 $file = $this->commonFileUpload('uploads/profile_images', $files['file']['name'],'file','',$old_file);
                if($file['status']==1):
                  $insertData['profile_image']=$file['image'];
                else:
                  $insertData['profile_image']='';
                endif; 
              endif;
        $this->mcommon->update('user_master',
                    array('user_id' =>$postData['userId']),
                    $insertData
                  );
        // echo $this->db->last_query();die;
          $this->session->set_flashdata('success_msg','Profile Updated Successfully!');
          endif;
        redirect('admin/dashboard','refresh');
    
  }
} 


