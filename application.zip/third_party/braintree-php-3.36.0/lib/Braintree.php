<?php
/**
 * Braintree PHP Library
 * Creates class_aliases for old class names replaced by PSR-4 Namespaces
 */
require_once __DIR__ . DIRECTORY_SEPARATOR .'Braintree.php';
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'autoload.php');
//echo __DIR__ . DIRECTORY_SEPARATOR . 'autoload.php';
if (version_compare(PHP_VERSION, '5.4.0', '<')) {
    throw new Braintree_Exception('PHP version >= 5.4.0 required');
}

// Instantiate a Braintree Gateway either like this:
$gateway = new Braintree_Gateway([
    'environment' => 'production',
                            'merchantId' => 'zqsbybc58xdhvjyf',
                            'publicKey' => 'fx6z2m8sfgx9xb5b',
                            'privateKey' => 'c446fcb32c6975c9d222fd572e9dbdff'
]);

$config = new Braintree_Configuration([
    'environment' => 'production',
                            'merchantId' => 'zqsbybc58xdhvjyf',
                            'publicKey' => 'fx6z2m8sfgx9xb5b',
                            'privateKey' => 'c446fcb32c6975c9d222fd572e9dbdff'
]);
$gateway = new Braintree\Gateway($config)
 ;
class Braintree {
    public static function requireDependencies() {
        $requiredExtensions = ['xmlwriter', 'openssl', 'dom', 'hash', 'curl'];
        foreach ($requiredExtensions AS $ext) {
            if (!extension_loaded($ext)) {
                throw new Braintree_Exception('The Braintree library requires the ' . $ext . ' extension.');
            }
        }
    }
}

echo($clientToken = $gateway->clientToken()->generate());

$result = $gateway->transaction()->sale([
    'amount' => '1000.00',
    'paymentMethodNonce' => '5345345345',
    'options' => [ 'submitForSettlement' => true ]
]); 

if ($result->success) {
    print_r("success!: " . $result->transaction->id);
} else if ($result->transaction) {
    print_r("Error processing transaction:");
    print_r("\n  code: " . $result->transaction->processorResponseCode);
    print_r("\n  text: " . $result->transaction->processorResponseText);
} else {
    print_r("Validation errors: \n");
    print_r($result->errors->deepAll());
}

Braintree::requireDependencies();
