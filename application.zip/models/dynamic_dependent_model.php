<?php
class Dynamic_dependent_model extends CI_Model
{
 function getCountry(){

        $response = array();
        
        // Select record
        $this->db->select('*');
        $q = $this->db->get('countries_master');
        $response = $q->result_array();

        return $response;
    }
}

?>
