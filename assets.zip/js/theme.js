// JavaScript Document
var bs = $('#banner-carousel');
bs.owlCarousel({
	autoplay:true,
	//autoplayTimeout:1000,
	//autoplaySpeed:700,
    loop:true,
    nav:true,
	dots:false,
	margin:0,
    //animateOut: 'slideOutDown',
    //animateIn: 'slideInRight',
	//animateOut: 'fadeOut',
    items: 1,
	navText: [ '<i class="fa fa-angle-left" aria-hidden="true"></i>', '<i class="fa fa-angle-right" aria-hidden="true"></i>' ],	
});



var bs = $('#services-carousel');
bs.owlCarousel({
	autoplay:true,
	//autoplayTimeout:1000,
	//autoplaySpeed:700,
	smartSpeed:1000,
    loop:true,
    nav:true,
	dots:true,
	margin:30,
	//animateOut: 'fadeOut',
    items: 4,
	navText: [ '<img src="assets/img/left-arrow.png">', '<img src="assets/img/right-arrow.png">' ],	
	responsive: {
			0: {
				items: 1
			},
			600: {
				items: 2
			},
			992: {
				items: 3
			},
			1024: {
				items: 4
			}
		}
});

var bs = $('#testimonial-carousel');
bs.owlCarousel({
	autoplay:true,
	//autoplayTimeout:1000,
	//autoplaySpeed:700,
	smartSpeed:1000,
    loop:true,
    nav:false,
	dots:true,
	margin:10,
	//animateOut: 'fadeOut',
    items: 1,
	//navText: [ '<img src="assets/img/left-arrow.png">', '<img src="assets/img/right-arrow.png">' ],	

});

	jQuery(document).ready(function($) {
			jQuery('.stellarnav').stellarNav({
				theme: 'light',
				breakpoint: 991,
				position: 'right',
				phoneBtn: '(780) 743-1904',
				//locationBtn: 'https://www.google.com/maps'
			});
			
});


const btns = document.querySelectorAll(".tabs__button");
const tabContent = document.querySelectorAll(".tab-content");

for (let i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", () => {
    addClassFunc(btns[i], "tabs__button--active");
    clearClassFunc(i, btns, "tabs__button--active");

    addClassFunc(tabContent[i], "tab-content--active");
    clearClassFunc(i, tabContent, "tab-content--active");
  });
}

function addClassFunc(elem, elemClass) {
  elem.classList.add(elemClass);
}

function clearClassFunc(indx, elems, elemClass) {
  for (let i = 0; i < elems.length; i++) {
    if (i === indx) {
      continue;
    }
    elems[i].classList.remove(elemClass);
  }
}



var bs = $('#supplies_slider');
bs.owlCarousel({
	autoplay:true,
	//autoplayTimeout:1000,
	//autoplaySpeed:700,
	smartSpeed:1000,
    loop:true,
    nav:true,
	dots:true,
	//animateOut: 'fadeOut',
    items: 1,
	navText: [ '<img src="assets/img/supplies_slider_l.png">', '<img src="assets/img/supplies_slider_r.png">' ],	
	responsive: {
			0: {
				items: 1
			},
			600: {
				items: 2
			},
			992: {
				items: 1
			},
			1024: {
				items: 1
			}
		}
});




var bs = $('#mobile_slider');
bs.owlCarousel({
	autoplay:true,
	//autoplayTimeout:1000,
	//autoplaySpeed:700,
	smartSpeed:1000,
    loop:true,
    nav:false,
	dots:true,
	//animateOut: 'fadeOut',
    items: 1,
	navText: [ '<img src="assets/img/supplies_slider_l.png">', '<img src="assets/img/supplies_slider_r.png">' ],	
	responsive: {
			0: {
				items: 1
			},
			600: {
				items: 2
			},
			992: {
				items: 1
			},
			1024: {
				items: 1
			}
		}
});






$("#toggle").click(function() {
	$(this).toggleClass("on");
	$("#menu").slideToggle();
  });

