$(document).ready(function(){

    $(document).on("click", ".change-p-status", function(e) {
    e.preventDefault();
    var status = $(this).attr("data-status");
    Swal.fire({
        position: 'top-end',
        title: "Are you sure want to do this ?",
        type: "warning",
        showCancelButton: true, // true or false  
        confirmButtonColor: "#dd6b55",
        cancelButtonColor: "#48cab2",
        confirmButtonText: "Yes !!!", 
    }).then((result) => {
        if (result.value) { 
            let id = $(this).attr("data-id");
            let indexKey = $(this).attr("data-key-id");
            let table = $(this).attr("data-table");
            let dataJson = {
                id: id,
                indexKey: indexKey,
                table: table,
                status: status,
            };
            if (id && table) {
                $.ajax({
                    type: "POST",
                    url: base_url + "admin/Dashboard/changeStatus",
                    data: dataJson,
                    dataType:"JSON",
                    success: function(res) {
                        
                        if (res.status.error_code == 0) {
                            if (status == 3) {
                                swalAlert("Data deleted successfully", "success");
                                setTimeout(function(){
                                  location.reload();
                                  //drawTable();
                                }, 1550);
                            } else { 
                                if (status == 0) {
                                    $("#" + id).attr("data-status", "1"); 
                                    $("#" + id).removeClass("text-success");
                                    $("#" + id).addClass("text-danger");
                                    $("#" + id).html("Inactive");
                                } else {
                                    $("#" + id).attr("data-status", "0");
                                    $("#" + id).removeClass("text-danger");
                                    $("#" + id).addClass("text-success");
                                    $("#" + id).html("Active");
                                }
                                swalAlert(res.status.message, "success");
                            }
                        } else {
                            swalAlert(res.status.message, "warning");
                        }
                    },
                });
            }
          }
      });
  });
})