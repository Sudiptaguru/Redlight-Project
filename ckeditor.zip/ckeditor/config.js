/**
 * @license Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';

	config.toolbarGroups = [
		{ name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
		{ name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
		{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
		{ name: 'forms', groups: [ 'forms' ] },
		'/',
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
		{ name: 'links', groups: [ 'links' ] },
		{ name: 'insert', groups: [ 'insert' ] },
		'/',
		{ name: 'styles', groups: [ 'styles' ] },
		{ name: 'colors', groups: [ 'colors' ] },
		{ name: 'tools', groups: [ 'tools' ] },
		{ name: 'others', groups: [ 'others' ] },
		{ name: 'about', groups: [ 'about' ] }
	];

	config.removeButtons = 'Source,Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Subscript,Superscript,CopyFormatting,RemoveFormat,NumberedList,BulletedList,Outdent,Indent,Blockquote,CreateDiv,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock,BidiLtr,BidiRtl,Language,Link,Unlink,Anchor,Flash,Table,HorizontalRule,Smiley,PageBreak,Iframe,Maximize,ShowBlocks,About';
	config.fontSize_sizes = '8/8px;9/9px;10/10px;11/11px;12/12px;14/14px;16/16px;18/18px;20/20px;22/22px;24/24px;26/26px;28/28px';


	// Remove some buttons provided by the standard plugins, which are
	// not needed in the Standard(s) toolbar.
	//config.removeButtons = 'Underline,Subscript,Superscript';

	// Set the most common block elements.
	config.format_tags = 'p;h1;h2;h3;pre';

	// Simplify the dialog windows.
	//config.removeDialogTabs = 'image:advanced;link:advanced';

	//config.filebrowserImageBrowseUrl = '/browser/browse.php?type=Images';

	//config.filebrowserImageUploadUrl = 'http://localhost/eflyerdepot/assets/frontend/vendor/ckeditor/uploader/upload.php?type=Images';

	config.filebrowserUploadMethod = 'form';

	config.extraPlugins = 'filebrowser';

	config.title = false;

	/* config.colorButton_backStyle = {
	    styles: { 'background-color': '#(color)' }
	};

	config.colorButton_colors = '00923E,F8C100,28166F';

	config.colorButton_colorsPerRow = 8;

	config.colorButton_enableAutomatic = true;

	config.colorButton_enableMore = true;

	config.colorButton_foreStyle = {
	    styles: { color: '#(color)' }
	};

	config.colorButton_normalizeBackground = true;*/

	config.allowedContent = true;
	
	config.filebrowserUploadUrl = 'http://inhouse.fitser.com/FlaschengeistAustPtyLtd/php/public/admin_assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    config.filebrowserImageUploadUrl = 'http://inhouse.fitser.com/FlaschengeistAustPtyLtd/php/public/admin_assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
    config.filebrowserFlashUploadUrl = 'http://inhouse.fitser.com/FlaschengeistAustPtyLtd/php/public/admin_assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
	
		
};
